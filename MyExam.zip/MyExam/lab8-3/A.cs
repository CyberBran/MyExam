﻿namespace lab8_3
{
    public class A
    {
        private int[] arr;
        
        public A(int s){
            arr=new int[s];
        }
        
        public int Length
        {
            get
            {
                return arr.Length;
            }
        }

        public int this[int index]
        {
            get
            {
                return arr[index];
            }
            set
            {
                arr[index] = value;
            }
        }


    }
}
