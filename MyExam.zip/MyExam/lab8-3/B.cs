﻿using System;
using System.Linq;

namespace lab8_3
{
    public class B : A
    {
        private char[] array;

        public B(int s):base(s){
            array=new char[s];
        }
        
        public int[] Length
        {
            get
            {
                return new int[]{array.Length, base.Length};
            }
        }
        public char this[int index]
        {
            get
            {
                return array[index];
            }
            set
            {
                array[index] = value;
            }

        }
    }
}
