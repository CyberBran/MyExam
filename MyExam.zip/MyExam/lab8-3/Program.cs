﻿using System;

namespace lab8_3
{
    class Program
    {
        static void Main(string[] args)
        {
            A a=new A(1);
            B b=new B(1);
            a[0]=1;
            b[0]='s';
            Console.WriteLine(a[0]);
            Console.WriteLine(b[0]);
            Console.WriteLine(b.Length[0]+" "+b.Length[1]);
        }
    }
}
