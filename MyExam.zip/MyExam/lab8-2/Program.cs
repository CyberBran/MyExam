﻿using System;

namespace lab8_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Calendar calendar = new Calendar();
            calendar["day"] = 07;
            calendar["month"] = 12;
            calendar["year"] = 20;
            Console.WriteLine(calendar.Calculate(07, 11, 20));
        }
    }
}
