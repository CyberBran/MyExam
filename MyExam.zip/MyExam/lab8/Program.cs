﻿using System;

namespace lab8
{
    class Program
    {
        static void Main(string[] args)
        {
            Index myIndex = new Index(1, 2);
            Console.WriteLine(myIndex[1]);
           
        }
    }
}
